$(document).ready(function(){

    /***
     * Get List Roles
     */
    $.ajax({
        url: "http://localhost:8080/crm1/api/role",
        method: "GET"
    }).done(function(result){
        $("#example tbody").empty()
        $.each(result,function(index,value){
            console.log(value)

            let row = `<tr>
                <td>${value.id}</td>
                <td>${value.name}</td>
                <td>${value.description}</td>
                <td>
                    <a href="#" class="btn btn-sm btn-primary">Sửa</a>
                    <a href="#" class="btn btn-sm btn-danger btn-delete" role-id="${value.id}">Xóa</a>
                </td>
            </tr>`

            $("#example tbody").append(row)
        })
    })

    /***
     * Delete Roles
     */
    $('body').on('click','.btn-delete',function(){
        // Lấy thuộc tính role-id từ button được click
        let roleId = $(this).attr('role-id')
        let This = $(this)

        $.ajax({
            url: `http://localhost:8080/crm1/api/role?id=${roleId}`,
            method: "DELETE",
        }).done(function(result){
            if(result.isSuccess == true){
                This.closest('tr').remove()
            }else{
                console.log("Xoá thất bại !")
            }
            location.reload();
        })
    })

    /***
     * Add Roles
     */
    $('#btn-save-role').click(function(e){
        e.preventDefault()
        $.ajax({
            url: `http://localhost:8080/crm1/api/role/add`,
            method: "POST",
            data: JSON.stringify({
                name: $('#role').val(),
                description: $('#description').val()
            }),
            contentType: "application/json",
            dataType: "json",
        }).done(function(result){
            if(result.isSuccess === true){
                $('#role').val("")
                $('#description').val("")
                $.toast({
                    heading: 'Success',
                    text: 'Thêm thành công.',
                    showHideTransition: 'slide',
                    position: 'top-center',
                    icon: 'success'
                })
            }else{
                console.log("Thêm thất bại !")
            }
        })
    })

    /***
     * Update Roles
     * => Using Postman
     */

})
